# _AUDIT_NOTE — ai-low-pesticide-agriculture (AgriSense)

## Stack
- node-express (backend, port 3001) + react/vite (frontend, port 5173)
- Postgres database `agri_db`
- Auth: JWT, login `admin@demo.com` / `demo123`
- LLM helper: existing `callAI` in `backend/routes/ai.js` (OpenRouter, model `anthropic/claude-haiku-4.5`)

## Feature add (8 features)

### AI features (5)
1. **Spray-Window Predictor** — `POST /api/ai/spray-window`
   - Reads field + recent `weather_data`, returns optimal low-drift spray windows
   - BE: `backend/routes/ai_extra.js`
   - FE: `frontend/src/components/SprayWindowPage.tsx` at `/ai/spray-window`
2. **Pesticide Residue Risk Scorer** — `POST /api/ai/residue-risk`
   - Reads recent `treatments` for a field + planned harvest date, scores residue risk and PHI/MRL compliance
   - BE: `backend/routes/ai_extra.js`
   - FE: `frontend/src/components/ResidueRiskPage.tsx` at `/ai/residue-risk`
3. **Soil Health Analyzer** — `POST /api/ai/soil-health`
   - Reads field + `health_reports` history + observations, returns regenerative practice plan
   - BE: `backend/routes/ai_extra.js`
   - FE: `frontend/src/components/SoilHealthPage.tsx` at `/ai/soil-health`
4. **Plant Disease Early-Warning** — `POST /api/ai/disease-early-warning`
   - Differential diagnosis from observed symptoms + recent `detections`
   - BE: `backend/routes/ai_extra.js`
   - FE: `frontend/src/components/DiseaseEarlyWarningPage.tsx` at `/ai/disease-early-warning`
5. **Beneficial Insect Identifier** — `POST /api/ai/beneficial-insects`
   - Identifies beneficials from scout notes, suggests habitat / spray-compat strategy
   - BE: `backend/routes/ai_extra.js`
   - FE: `frontend/src/components/BeneficialInsectsPage.tsx` at `/ai/beneficial-insects`

All 5 use a `callOpenRouter` helper that returns **HTTP 503** when `OPENROUTER_API_KEY` is missing; the FE pages render a visible amber 503 notice in that case.

### Utility features (3)
6. **CSV Export of Fields (main entity)** — `GET /api/utility/export/fields.csv`
   - BE: `backend/routes/utility.js`
   - FE: `frontend/src/components/ExportPage.tsx` at `/utility/export`
7. **Global Search + Filter** — `GET /api/utility/search?q=&type=&status=`
   - Searches fields, detections, treatments, health_reports, sensors
   - BE: `backend/routes/utility.js`
   - FE: `frontend/src/components/SearchPage.tsx` at `/utility/search`
8. **Activity Feed / Audit Log** — `GET /api/utility/activity?limit=`
   - Read-only timeline aggregated from existing tables (no new tables)
   - BE: `backend/routes/utility.js`
   - FE: `frontend/src/components/ActivityFeedPage.tsx` at `/utility/activity`

### Files touched
- Backend (new): `backend/routes/ai_extra.js`, `backend/routes/utility.js`
- Backend (modified, registration only): `backend/server.js`
- Frontend (new): `frontend/src/components/AIToolPage.tsx` (shared helper), `SprayWindowPage.tsx`, `ResidueRiskPage.tsx`, `SoilHealthPage.tsx`, `DiseaseEarlyWarningPage.tsx`, `BeneficialInsectsPage.tsx`, `ExportPage.tsx`, `SearchPage.tsx`, `ActivityFeedPage.tsx`
- Frontend (modified, additive): `frontend/src/App.tsx`, `frontend/src/components/Layout.tsx`, `frontend/src/api.ts`

### Notes
- Existing endpoints, auth, and DB schema were left untouched.
- No `npm install` / no new dependencies. No schema changes.
- All new backend files pass `node --check`. All new/changed frontend files pass `esbuild` parse.

## Smoke test (run after feature-add)
- backend started: PASS
- login: PASS
- new endpoint reachable (auth): PASS

## Sample data buttons

Added a "Sample Data" page (route `/admin/sample-data`, sidebar group "Dev Tools") with one button per main entity. Each button POSTs to a new JWT-protected endpoint that inserts 5–10 domain-realistic rows (low-pesticide / IPM / sustainable agriculture). Inserts are additive — no wipes.

### Files
- Backend (new): `backend/routes/sample_data.js` — `POST /api/admin/sample-data/:entity` returning `{inserted, entity}`
- Backend (modified, registration only): `backend/server.js` — `app.use('/api/admin', require('./routes/sample_data'))`
- Frontend (new): `frontend/src/components/SampleDataPage.tsx`
- Frontend (modified, additive): `frontend/src/App.tsx`, `frontend/src/components/Layout.tsx`

### Entities + button labels
- `fields` — "Add 8 sample fields" (CA strawberry, vineyard, almond, lettuce, walnut, apple, bell pepper, processing tomato)
- `detections` — "Add 8 sample detections" (codling moth, spider mite, lygus, NOW, aphid, thrips, armyworm, etc.)
- `treatments` — "Add 8 sample treatments" (pheromone disruption, Bt, neem, Spinosad OMRI, beneficial mites, kaolin clay, sanitation pruning, insecticidal soap)
- `health_reports` — "Add 7 sample health reports" (NDVI + yield estimates with scout/agronomist/drone reporters)
- `sensors` — "Add 8 sample sensors" (Sentek probes, Davis stations, Trapview, METER, DJI multispec, Semios)
- `weather_data` — "Add 8 sample weather rows" (CA growing regions with pest-risk index)

Whitelist enforced server-side; `users` / `audit_log` / unknown entity → HTTP 400. Missing token → HTTP 401. FK-safe: child entities auto-create parent `fields` rows when none exist yet.

### Smoke test (live)
- Login `admin@demo.com` / `demo123`: PASS (HTTP 200)
- All 6 entity endpoints: PASS (HTTP 200, `inserted` 7–8)
- Bad entity rejected: PASS (HTTP 400)
- Unauthenticated rejected: PASS (HTTP 401)

### Notes
- Existing endpoints, auth, schema untouched. No `npm install`.
- All new files pass `node --check` / `esbuild` parse.

## AI feature samples

Added sample-prefill buttons to every AI feature page so a user can click a sample chip and immediately run "Generate Analysis" without typing. The shared `AIToolPage` component already supported `samples?: SampleSpec[]`; this change adds the data and extends `AICenter.tsx` (which has its own inline form rendering) with the same pattern.

### Files modified (frontend, additive only)
- `frontend/src/components/SprayWindowPage.tsx` — 3 samples (codling moth / NOW / lygus)
- `frontend/src/components/ResidueRiskPage.tsx` — 3 samples (strawberry 7d / lettuce 14d / vineyard 30d)
- `frontend/src/components/SoilHealthPage.tsx` — 3 samples (sandy loam / clay loam / hillside)
- `frontend/src/components/DiseaseEarlyWarningPage.tsx` — 3 samples (powdery mildew / Verticillium / fire blight)
- `frontend/src/components/BeneficialInsectsPage.tsx` — 3 samples (lady beetles / parasitic wasps / lacewings)
- `frontend/src/components/AICenter.tsx` — extended `AITool` with optional `samples` and renders pill buttons; 3 samples for each of the 4 embedded tools (pest pattern, yield prediction, treatment plan, field summary)

Total: 27 samples across 9 AI tool surfaces. All values use real CA crops (strawberry, almond, vineyard, lettuce, apple), real pests (codling moth, navel orangeworm, lygus bug, vine mealybug), real diseases (powdery mildew, Verticillium wilt, fire blight), and real beneficials (lady beetles, Trichogramma, lacewings, syrphids).

### Smoke test (live)
- `pkill -9` + `./start.sh`: PASS
- backend port 3001 reachable: PASS
- login `admin@demo.com` / `demo123`: PASS (HTTP 200, JWT returned)
- Vite frontend bundle compile: PASS (`VITE v5.4.21  ready in 162 ms`)
- cleanup `pkill -9`: PASS

### Notes
- No existing logic changed beyond adding the `samples` prop / extending the `AITool` interface and adding the sample-pill render block in `AICenter`.
- No `npm install` / no new dependencies.
- All 6 modified files pass `npx esbuild` parse.
- Log: `/Users/erolakarsu/projects/_AUDIT/apply3_logs/samples_ai-low-pesticide-agriculture.md`
