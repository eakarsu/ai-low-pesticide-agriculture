const recentDetections = [
  { id: 1, field: 'North Field A', pest: 'Aphid cluster', confidence: 94, status: 'treated' },
  { id: 2, field: 'East Block 3', pest: 'Powdery mildew', confidence: 87, status: 'pending' },
  { id: 3, field: 'South Orchard', pest: 'Spider mites', confidence: 91, status: 'treated' },
  { id: 4, field: 'West Field 2', pest: 'Cutworm', confidence: 78, status: 'pending' },
  { id: 5, field: 'Greenhouse 1', pest: 'Whitefly', confidence: 96, status: 'treated' },
]

const stats = [
  { label: 'Fields Monitored', value: '24', change: '+2 this week', color: 'bg-green-50 border-green-200', valueColor: 'text-green-700' },
  { label: 'Pests Detected Today', value: '3', change: '-5 vs yesterday', color: 'bg-amber-50 border-amber-200', valueColor: 'text-amber-700' },
  { label: 'Chemical Reduction', value: '87%', change: '+3% this month', color: 'bg-emerald-50 border-emerald-200', valueColor: 'text-emerald-700' },
  { label: 'Cost Saved', value: '$12,400', change: '+$1,200 this month', color: 'bg-teal-50 border-teal-200', valueColor: 'text-teal-700' },
]

export default function Dashboard() {
  return (
    <div className="space-y-8">
      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-5">
        {stats.map((s) => (
          <div key={s.label} className={`rounded-xl border p-5 ${s.color}`}>
            <div className="text-sm text-stone-500 font-medium mb-1">{s.label}</div>
            <div className={`text-3xl font-bold ${s.valueColor}`}>{s.value}</div>
            <div className="text-xs text-stone-400 mt-1">{s.change}</div>
          </div>
        ))}
      </div>

      {/* Recent detections */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <h2 className="font-semibold text-stone-800">Recent Detections</h2>
          <span className="text-xs text-stone-400">Updated 2 min ago</span>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-stone-50 text-stone-500 text-xs uppercase tracking-wide">
            <tr>
              <th className="text-left px-6 py-3">Field Name</th>
              <th className="text-left px-6 py-3">Pest / Weed</th>
              <th className="text-left px-6 py-3">Confidence</th>
              <th className="text-left px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {recentDetections.map((d) => (
              <tr key={d.id} className="hover:bg-stone-50 transition-colors">
                <td className="px-6 py-3.5 font-medium text-stone-700">{d.field}</td>
                <td className="px-6 py-3.5 text-stone-600">{d.pest}</td>
                <td className="px-6 py-3.5">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-stone-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-green-500 rounded-full"
                        style={{ width: `${d.confidence}%` }}
                      />
                    </div>
                    <span className="text-stone-600">{d.confidence}%</span>
                  </div>
                </td>
                <td className="px-6 py-3.5">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    d.status === 'treated'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {d.status.charAt(0).toUpperCase() + d.status.slice(1)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-3 gap-5">
        <div className="bg-white rounded-xl border border-stone-200 p-5">
          <div className="text-sm font-medium text-stone-500 mb-3">Weekly Scan Coverage</div>
          <div className="space-y-2">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day, i) => {
              const pct = [100, 95, 88, 100, 72][i]
              return (
                <div key={day} className="flex items-center gap-3 text-sm">
                  <span className="w-8 text-stone-400">{day}</span>
                  <div className="flex-1 h-2 bg-stone-100 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-8 text-right text-stone-600">{pct}%</span>
                </div>
              )
            })}
          </div>
        </div>
        <div className="bg-white rounded-xl border border-stone-200 p-5">
          <div className="text-sm font-medium text-stone-500 mb-3">Pest Types Detected (30d)</div>
          <div className="space-y-2">
            {[
              { name: 'Aphids', count: 12, pct: 80 },
              { name: 'Mildew', count: 8, pct: 53 },
              { name: 'Spider Mites', count: 6, pct: 40 },
              { name: 'Cutworms', count: 3, pct: 20 },
            ].map((p) => (
              <div key={p.name} className="flex items-center gap-3 text-sm">
                <span className="w-24 text-stone-600 truncate">{p.name}</span>
                <div className="flex-1 h-2 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${p.pct}%` }} />
                </div>
                <span className="w-4 text-right text-stone-500">{p.count}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-xl border border-stone-200 p-5">
          <div className="text-sm font-medium text-stone-500 mb-3">AI Model Performance</div>
          <div className="space-y-3">
            {[
              { label: 'Precision', value: '94.2%' },
              { label: 'Recall', value: '91.8%' },
              { label: 'F1 Score', value: '93.0%' },
              { label: 'Avg Inference', value: '1.4s' },
            ].map((m) => (
              <div key={m.label} className="flex justify-between text-sm">
                <span className="text-stone-500">{m.label}</span>
                <span className="font-semibold text-stone-700">{m.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
